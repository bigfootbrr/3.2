import sys
import unittest
from pathlib import Path
from unittest.mock import patch


RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ / "web"))

import interface_tempo_real


class InterfaceWebOtcTest(unittest.TestCase):
    def test_iniciar_otc_preserva_mercado_e_ativo_selecionados(self):
        with patch.object(interface_tempo_real, "criar_conector_padrao", return_value=object()):
            interface = interface_tempo_real.InterfaceTempoReal()
        interface.mudar_ativo("EUR/GBP (OTC)")
        interface.confirmar_plataforma()

        with patch.object(interface_tempo_real, "iniciar_robo") as iniciar_robo:
            iniciado, _ = interface.iniciar_motor()

        self.assertTrue(iniciado)
        iniciar_robo.assert_called_once()
        argumentos = iniciar_robo.call_args.kwargs
        self.assertEqual("OTC", argumentos["tipo_mercado"])
        self.assertEqual("EUR/GBP (OTC)", argumentos["ativo"])

    def test_painel_permanece_na_aba_otc_apos_recarregar(self):
        conector = unittest.mock.Mock()
        conector.obter_cotacao.return_value = None
        with patch.object(interface_tempo_real, "criar_conector_padrao", return_value=conector):
            interface = interface_tempo_real.InterfaceTempoReal()
        interface.mudar_ativo("EUR/GBP (OTC)")

        html = interface.gerar_html()

        self.assertIn('class="asset-mode active" id="aba-otc"', html)
        self.assertIn('class="asset-view active" id="mercado-otc"', html)
        self.assertIn('class="asset-view" id="mercado-aberto"', html)

    def test_painel_recebe_analise_otc_emitida_pelo_motor(self):
        with patch.object(interface_tempo_real, "criar_conector_padrao", return_value=object()):
            interface = interface_tempo_real.InterfaceTempoReal()
        interface.mudar_ativo("EUR/GBP (OTC)")
        evento = {
            "tipo": "sinal",
            "mercado": "OTC",
            "ativo": "EUR/GBP (OTC)",
            "sinal": "ALTA",
            "direcao": "CALL / HIGHER",
            "pontuacao": 8.0,
        }

        interface.receber_evento_motor(evento)

        self.assertEqual(evento, interface.ultima_analise)
        self.assertEqual("8.0/10", interface.estado_operacional["confluencia"])
        self.assertEqual("CALL / HIGHER", interface.estado_operacional["entrada"])


if __name__ == "__main__":
    unittest.main()
