"""Interface web final com dados reais de mercado em tempo real.

Serve uma interface HTML em um servidor HTTP local e expõe endpoints REST
que se conectam ao motor do BFT WIN para iniciar, pausar, parar e configurar
operações, além de fornecer cotações reais.
"""

import json
import os
import sys
import threading
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Dict, List, Optional
from urllib.parse import parse_qs, unquote, urlparse

PASTA_PROJETO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(PASTA_PROJETO, "core"))

from conector_mercado_real import ConectorMercadoReal, criar_conector_padrao
from main import (
  acionar_parada_emergencia,
  definir_callback_evento,
  iniciar_robo,
  pausar_robo,
)
from modo_operacao import SOMENTE_SINAIS
from painel_abas_iq import ATIVOS_MERCADO_ABERTO, ATIVOS_OTC_PRIORITARIOS


class InterfaceTempoReal:
    """Interface web integrada com dados reais de mercado."""

    PLATAFORMAS = ("IQ Option", "Quotex", "Casa Trader", "Avallon")
    ATIVOS_DESTAQUE = (
        "EUR/USD",
        "EUR/JPY",
        "EUR/GBP",
        "GBP/USD",
        "GBP/JPY",
        "USD/JPY",
        "USD/CHF",
        "USD/CAD",
        "AUD/USD",
        "USD/SEK",
        "USD/NOK",
        "USD/DKK",
        "USD/HKD",
        "USD/SGD",
        "USD/KRW",
    )

    def __init__(self):
        self.conector = criar_conector_padrao()
        self.ativos_selecionados = list(self.ATIVOS_DESTAQUE)
        self.ativo_atual = "EUR/USD"
        self.logs = []
        self.estado_operacional = {
            "status": "Parado",
            "banca": 1000.00,
            "payout": 0.0,
            "confluencia": "—",
            "entrada": "Confirme a plataforma",
        }
        self.configuracao = {
            "entrada": 25.0,
            "stop_gain": 100.0,
            "stop_loss": 100.0,
        }
        self.historico_velas = {}
        self.threads_atualizacao = {}
        self.motor_ativo = False
        self.motor_pausado = False
        self.plataforma_atual = "IQ Option"
        self.plataforma_confirmada = None
        self.ultima_analise = None
        self.lock_analise = threading.Lock()
        definir_callback_evento(self.receber_evento_motor)

    def _status_painel(self) -> str:
        """Resume o estado exibido no topo do painel."""
        return self.estado_operacional["status"]

    def _resolver_ativo_motor(self) -> Optional[str]:
        """Converte o código exibido na web para o formato aceito pelo motor."""
        ativo = self.ativo_atual.strip().upper()
        if ativo in ATIVOS_MERCADO_ABERTO:
            return ativo
        if "/" not in ativo and len(ativo) == 6:
            candidato = f"{ativo[:3]}/{ativo[3:]}"
            if candidato in ATIVOS_MERCADO_ABERTO:
                return candidato
        return None

    @staticmethod
    def _codigo_cotacao(ativo: str) -> str:
        return ativo.replace("/", "").upper()

    @staticmethod
    def _ativos_equivalentes(primeiro: str, segundo: str) -> bool:
        return primeiro.replace("/", "").upper() == segundo.replace("/", "").upper()

    def receber_evento_motor(self, evento: Dict):
        """Mantém a análise mais recente do ativo exibido no Trading Desk."""
        if evento.get("tipo") != "radar_mercado_aberto":
            return
        if not self._ativos_equivalentes(evento.get("ativo", ""), self.ativo_atual):
            return

        with self.lock_analise:
            self.ultima_analise = dict(evento)

        pontuacao = evento.get("pontuacao", 0)
        sinal = evento.get("direcao", evento.get("sinal", "AGUARDAR"))
        self.estado_operacional["confluencia"] = f"{pontuacao:.1f}/10"
        self.estado_operacional["entrada"] = sinal
        self.registrar_log(
            "ANALISE",
            f"{evento.get('ativo', '—')}: {sinal} | confluência {pontuacao:.1f}/10",
            "ok" if sinal in {"CALL", "PUT"} else "info",
        )

    def registrar_log(self, tipo: str, mensagem: str, nivel: str = "info"):
        """Registra mensagem no log."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        entrada = {
            "timestamp": timestamp,
            "tipo": tipo,
            "mensagem": mensagem,
            "nivel": nivel,  # "info", "ok", "warn", "error"
        }
        self.logs.append(entrada)
        # Manter apenas últimos 50 logs
        if len(self.logs) > 50:
            self.logs = self.logs[-50:]
        print(f"[{timestamp}] [{tipo}] {mensagem}")

    def mudar_ativo(self, ativo: str):
        """Muda o ativo selecionado."""
        ativo = unquote(ativo).strip().upper()
        if (
            ativo in ATIVOS_MERCADO_ABERTO
            or ativo in ATIVOS_OTC_PRIORITARIOS
        ):
            self.ativo_atual = ativo
            with self.lock_analise:
                self.ultima_analise = None
            if ativo not in self.ativos_selecionados:
                self.ativos_selecionados.append(ativo)
            self.registrar_log("ATIVO", f"Ativo alterado para {ativo}", "ok")
            return True
        self.registrar_log("ATIVO", f"Ativo inválido: {ativo}", "warn")
        return False

    def adicionar_ativo(self, ativo: str):
        """Adiciona opcionalmente um par Forex real ao acompanhamento."""
        ativo = unquote(ativo).strip().upper()
        if "/" not in ativo and len(ativo) == 6:
            ativo = f"{ativo[:3]}/{ativo[3:]}"
        if ativo in ATIVOS_MERCADO_ABERTO:
            if ativo not in self.ativos_selecionados:
                self.ativos_selecionados.append(ativo)
            self.registrar_log("ATIVO", f"Ativo {ativo} adicionado", "ok")
            return True
        self.registrar_log("ATIVO", f"Ativo não suportado: {ativo}", "warn")
        return False

    def atualizar_banca(self, banca: float):
        """Atualiza banca operacional."""
        self.estado_operacional["banca"] = float(banca)
        self.registrar_log("BANCA", f"Banca atualizada para {banca:.2f}", "ok")

    def atualizar_configuracao(self, dados: Dict):
        """Atualiza os limites locais usados ao iniciar a análise."""
        campos = {
            "banca": "banca",
            "entrada": "entrada",
            "stop_gain": "stop_gain",
            "stop_loss": "stop_loss",
        }
        valores = {}
        for campo, destino in campos.items():
            if campo not in dados:
                continue
            valor = float(dados[campo])
            if valor <= 0:
                raise ValueError(f"{campo} deve ser maior que zero")
            valores[destino] = valor

        if "banca" in valores:
            self.atualizar_banca(valores.pop("banca"))
        self.configuracao.update(valores)
        if valores:
            self.registrar_log("RISCO", "Configuração operacional atualizada", "ok")

    def mudar_plataforma(self, plataforma: str):
        """Trocar a plataforma exige nova confirmação operacional."""
        if plataforma not in self.PLATAFORMAS:
            raise ValueError("plataforma não suportada")
        self.plataforma_atual = plataforma
        self.plataforma_confirmada = None
        self.estado_operacional["entrada"] = "Confirme a plataforma"
        self.registrar_log(
            "PLATAFORMA",
            f"{plataforma} selecionada; confirmação necessária",
            "warn",
        )

    def confirmar_plataforma(self):
        """Confirma a plataforma escolhida para o monitoramento da sessão."""
        self.plataforma_confirmada = self.plataforma_atual
        if not self.motor_ativo:
            self.estado_operacional["entrada"] = "Pronta para iniciar"
        self.registrar_log(
            "PLATAFORMA",
            f"Plataforma confirmada: {self.plataforma_confirmada}",
            "ok",
        )

    def conectar_conta(self):
        """Marca o painel como pronto para monitoramento manual."""
        self.estado_operacional["status"] = "Painel preparado"
        self.estado_operacional["entrada"] = "Pronta para monitorar"
        self.registrar_log(
            "CONTA",
            "Painel preparado para acompanhar sinais sem ordens automáticas",
            "ok",
        )
        return True

    def iniciar_motor(self):
        """Inicia a análise do motor compartilhado em modo somente sinais."""
        if self.plataforma_confirmada != self.plataforma_atual:
            mensagem = "Confirme a plataforma antes de iniciar o monitoramento"
            self.registrar_log("PLATAFORMA", mensagem, "warn")
            return False, mensagem
        if self.motor_ativo and not self.motor_pausado:
            self.registrar_log("MOTOR", "Motor já está rodando", "warn")
            return False, "Motor já está rodando"

        ativo = self._resolver_ativo_motor() or "EUR/USD"
        try:
            iniciar_robo(
                self.estado_operacional["banca"],
                self.configuracao["entrada"],
                self.configuracao["stop_gain"],
                self.configuracao["stop_loss"],
                "Automático",
                tipo_mercado="MERCADO ABERTO",
                modo_operacao=SOMENTE_SINAIS,
                ativo=ativo,
            )
        except ValueError as erro:
            self.registrar_log("MOTOR", f"Motor bloqueado: {erro}", "error")
            return False, str(erro)

        self.motor_ativo = True
        self.motor_pausado = False
        self.estado_operacional["status"] = "Rodando — somente sinais"
        self.estado_operacional["entrada"] = "Em análise"
        if self._resolver_ativo_motor() is None:
            self.registrar_log(
                "MOTOR",
                f"{self.ativo_atual} não é Forex; análise iniciada em {ativo}",
                "warn",
            )
        self.registrar_log(
            "MOTOR", "Análise BFT iniciada — sem ordens automáticas", "ok"
        )
        return True, "Motor iniciado em modo somente sinais"

    def pausar_motor(self):
        """Pausa o motor do BFT WIN."""
        if not self.motor_ativo:
            self.registrar_log("MOTOR", "Motor ainda não foi iniciado", "warn")
            return False, "Motor ainda não foi iniciado"
        if self.motor_pausado:
            self.registrar_log("MOTOR", "Motor já está pausado", "warn")
            return False, "Motor já está pausado"

        pausar_robo()
        self.motor_pausado = True
        self.estado_operacional["status"] = "Pausado — somente sinais"
        self.estado_operacional["entrada"] = "Monitoramento pausado"
        self.registrar_log("MOTOR", "Motor do BFT WIN pausado", "warn")
        return True, "Motor pausado"

    def parada_emergencia(self):
        """Executa parada de emergência."""
        acionar_parada_emergencia()
        self.motor_ativo = False
        self.motor_pausado = False
        self.estado_operacional["status"] = "EMERGÊNCIA — tudo parado"
        self.estado_operacional["entrada"] = "Bloqueada"
        self.registrar_log("EMERGENCIA", "PARADA DE EMERGÊNCIA ACIONADA", "error")
        return True, "Parada de emergência acionada"

    def gerar_html(self) -> str:
        """Gera HTML da interface com dados reais."""
        cotacoes = {}
        codigo_ativo = self._codigo_cotacao(self.ativo_atual)
        cotacao = self.conector.obter_cotacao(codigo_ativo)
        if cotacao:
            cotacoes[self.ativo_atual] = cotacao

        ativo_selecionado = cotacoes.get(self.ativo_atual)

        # Métrica de mudança de preço
        mudanca = ""
        mudanca_cor = "green"
        if ativo_selecionado:
            if ativo_selecionado.variacao_percentual > 0:
                mudanca = f"+{ativo_selecionado.variacao_percentual:.2f}%"
            else:
                mudanca = f"{ativo_selecionado.variacao_percentual:.2f}%"
                mudanca_cor = "red"

        # Log formatado
        log_html = "\n".join(
            [
                f'<div><span class="log-tag">[{log["tipo"]}]</span> '
                f'<span class="{log["nivel"]}">{log["mensagem"]}</span></div>'
                for log in self.logs[-10:]
            ]
        )

        def botoes_ativos(ativos):
          return "\n".join(
            f'<button class="tab {"active" if ativo == self.ativo_atual else ""}" '
            f'onclick="mudar_ativo(\'{ativo}\')">{ativo}</button>'
            for ativo in ativos
          )

        principais_html = botoes_ativos(self.ATIVOS_DESTAQUE[:6])
        adicionais_html = botoes_ativos(
          ativo
          for ativo in ATIVOS_MERCADO_ABERTO
          if ativo not in self.ATIVOS_DESTAQUE[:6]
        )
        otc_html = botoes_ativos(ATIVOS_OTC_PRIORITARIOS)

        return f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>BFT Winbot — Trading Desk (Tempo Real)</title>
<style>
  :root{{
    --bg-0:#0a0812;
    --bg-1:#100c1c;
    --bg-2:#171229;
    --bg-3:#1e1834;
    --line:#2a2440;
    --line-strong:#3C3489;
    --purple-50:#EEEDFE;
    --purple-100:#CECBF6;
    --purple-200:#AFA9EC;
    --purple-400:#7F77DD;
    --purple-600:#534AB7;
    --purple-800:#3C3489;
    --text-1:#F1EFFB;
    --text-2:#9A93C9;
    --text-3:#6B6494;
    --green:#639922;
    --green-light:#97C459;
    --red:#E24B4A;
    --red-light:#F09595;
    --amber:#EF9F27;
    font-family:'Inter','Segoe UI',system-ui,-apple-system,sans-serif;
  }}
  *{{box-sizing:border-box;margin:0;padding:0;}}
  body{{
    background:radial-gradient(circle at 20% 0%, #14102450, transparent 55%), var(--bg-0);
    color:var(--text-1);
    min-height:100vh;
    padding:32px 16px 80px;
  }}
  .shell{{max-width:980px;margin:0 auto;}}

  .topbar{{
    display:flex;align-items:center;justify-content:space-between;
    padding:14px 20px;background:var(--bg-1);border:0.5px solid var(--line);
    border-radius:14px;margin-bottom:16px;
  }}
  .brand{{display:flex;align-items:center;gap:12px;}}
  .brand-mark{{
    width:48px;height:48px;border-radius:10px;background:#fff;
    border:1px solid var(--purple-400);padding:3px;overflow:hidden;
  }}
  .brand-mark img{{display:block;width:100%;height:100%;object-fit:contain;}}
  .brand h1{{font-size:16px;font-weight:600;letter-spacing:-0.01em;}}
  .brand p{{font-size:11.5px;color:var(--text-2);margin-top:1px;}}
  .status-pill{{
    display:flex;align-items:center;gap:7px;
    background:var(--bg-2);border:0.5px solid var(--line-strong);
    border-radius:99px;padding:7px 14px;font-size:12px;color:var(--purple-100);
  }}
  .dot{{width:7px;height:7px;border-radius:50%;background:var(--amber);
       box-shadow:0 0 6px var(--amber);}}

  .grid-4{{
    display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px;
  }}
  .grid-3{{
    display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:14px;
  }}
  .metric{{
    background:var(--bg-1);border:0.5px solid var(--line);border-radius:12px;
    padding:14px 16px;
  }}
  .metric.danger{{border-color:#5a2323;background:#1e1112;}}
  .metric-label{{font-size:11px;color:var(--text-2);margin-bottom:6px;text-transform:none;}}
  .metric-value{{font-size:19px;font-weight:600;}}
  .metric-value.green{{color:var(--green-light);}}
  .metric-value.purple{{color:var(--purple-200);}}
  .metric-value.red{{color:var(--red-light);}}

  .panel{{
    background:var(--bg-1);border:0.5px solid var(--line);border-radius:14px;
    padding:18px;margin-bottom:16px;
  }}
  .panel-header{{
    display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;
  }}
  .panel-title{{font-size:13px;color:var(--text-2);}}
  .pair-badge{{
    font-size:12px;color:var(--text-2);background:var(--bg-2);
    border:0.5px solid var(--line);border-radius:8px;padding:4px 10px;
  }}
  .change-up{{color:var(--green-light);font-size:12.5px;font-weight:500;}}
  .change-down{{color:var(--red-light);font-size:12.5px;font-weight:500;}}

  .chart-wrap{{width:100%;height:220px;}}

  .btn-row{{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px;}}
  .btn-row.wide{{grid-template-columns:1fr;}}
  button{{
    font-family:inherit;font-size:13px;font-weight:500;
    border-radius:10px;padding:12px 14px;cursor:pointer;
    transition:filter .15s ease, transform .1s ease;border:none;
  }}
  button:active{{transform:scale(0.98);}}
  .btn-primary{{
    background:linear-gradient(180deg,var(--purple-600),var(--purple-800));
    border:0.5px solid var(--purple-400);color:var(--purple-50);
  }}
  .btn-primary:hover{{filter:brightness(1.12);}}
  .btn-ghost{{
    background:transparent;border:0.5px solid var(--line-strong);color:var(--purple-200);
  }}
  .btn-ghost:hover{{background:var(--bg-2);}}
  .btn-danger-full{{
    width:100%;margin-top:20px;background:linear-gradient(180deg,#9c2b2b,#6b1c1c);
    border:0.5px solid #c33; color:#ffe3e3; font-size:14px; font-weight:600;
    padding:15px; letter-spacing:0.02em; display:flex; align-items:center; justify-content:center; gap:8px;
  }}
  .btn-danger-full:hover{{filter:brightness(1.1);}}

  .tabs{{display:flex;gap:4px;margin-bottom:14px;overflow-x:auto;}}
  .tab{{
    font-size:12.5px;color:var(--text-2);background:transparent;
    border:0.5px solid var(--line);padding:8px 14px;border-radius:9px;
    white-space:nowrap;cursor:pointer;
  }}
  .tab.active{{background:var(--bg-2);color:var(--text-1);border-color:var(--line-strong);}}
  .asset-toolbar{{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:14px;}}
  .asset-modes{{display:flex;gap:6px;}}
  .asset-mode{{padding:8px 12px;color:var(--text-2);background:transparent;border:0.5px solid var(--line);}}
  .asset-mode.active{{color:var(--purple-50);border-color:var(--purple-400);background:var(--bg-2);}}
  .asset-view{{display:none;}}
  .asset-view.active{{display:block;}}
  .asset-grid{{display:flex;flex-wrap:wrap;gap:7px;}}
  .asset-extra{{display:none;margin-top:10px;}}
  .asset-extra.aberto{{display:flex;}}
  .asset-link{{margin-top:10px;padding:8px 12px;color:var(--purple-200);background:transparent;border:0.5px dashed var(--line-strong);}}
  .asset-note{{font-size:12px;color:var(--text-2);margin-bottom:10px;}}
  .asset-optional{{margin-top:12px;color:var(--text-2);font-size:12px;}}
  .asset-optional summary{{cursor:pointer;}}
  .asset-optional button{{margin-top:8px;padding:8px 12px;color:var(--purple-200);background:transparent;border:0.5px solid var(--line-strong);}}

  .form-row{{margin-bottom:12px;}}
  .form-row label{{display:block;font-size:11.5px;color:var(--text-2);margin-bottom:6px;}}
  .form-row input{{
    width:100%;background:var(--bg-2);border:0.5px solid var(--line);
    border-radius:9px;padding:10px 12px;color:var(--text-1);font-size:13.5px;
  }}
  .form-row select{{
    width:100%;background:var(--bg-2);border:0.5px solid var(--line);
    border-radius:9px;padding:10px 12px;color:var(--text-1);font-size:13.5px;
  }}
  .form-row input:focus{{outline:none;border-color:var(--purple-400);}}
  .form-grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;}}
  .form-state{{
    min-height:41px;display:flex;align-items:center;padding:10px 12px;
    background:var(--bg-2);border:0.5px solid var(--line);border-radius:9px;
    color:var(--amber);font-size:13.5px;
  }}
  .form-state.confirmada{{color:var(--green-light);border-color:#466c27;}}

  @media (max-width:720px){{
    .grid-4,.grid-3,.form-grid{{grid-template-columns:1fr 1fr;}}
    .topbar{{align-items:flex-start;gap:12px;}}
  }}
  @media (max-width:460px){{
    .grid-4,.grid-3,.form-grid,.btn-row{{grid-template-columns:1fr;}}
  }}

  .log{{
    background:#0c0a15;border:0.5px solid var(--line);border-radius:10px;
    padding:12px 14px;font-family:'SFMono-Regular',Consolas,'Courier New',monospace;
    font-size:11.5px;line-height:1.7;color:var(--text-2);max-height:160px;overflow-y:auto;
  }}
  .log .ok{{color:var(--green-light);}}
  .log .warn{{color:var(--amber);}}
  .log .error{{color:var(--red-light);}}
  .log-tag{{color:var(--purple-200);}}

  footer{{text-align:center;font-size:11px;color:var(--text-3);margin-top:20px;}}

  .pulse {{animation: pulse 1.5s ease-in-out infinite;}}
  @keyframes pulse {{
    0%, 100% {{ opacity: 1; }}
    50% {{ opacity: 0.7; }}
  }}
</style>
</head>
<body>
<div class="shell">

  <div class="topbar">
    <div class="brand">
      <div class="brand-mark">
        <img src="/assets/logo-bft.jpg" alt="BFT WIN">
      </div>
      <div>
        <h1>BFT Winbot</h1>
        <p>Tempo Real — Mercados Globais</p>
      </div>
    </div>
    <div class="status-pill">
      <span class="dot pulse"></span>
      <span id="status-painel">{self._status_painel()}</span>
    </div>
  </div>

  <div class="grid-4">
    <div class="metric">
      <div class="metric-label">Banca operacional</div>
      <div class="metric-value purple" id="banca-metrica">${self.estado_operacional['banca']:,.2f}</div>
    </div>
    <div class="metric">
      <div class="metric-label">Payout máximo</div>
      <div class="metric-value green" id="payout-metrica">{self.estado_operacional['payout']:.0f}%</div>
    </div>
    <div class="metric">
      <div class="metric-label">Confluência</div>
      <div class="metric-value purple" id="confluencia-metrica">{self.estado_operacional['confluencia']}</div>
    </div>
    <div class="metric danger">
      <div class="metric-label" style="color:#F09595">Status entrada</div>
      <div class="metric-value red" id="entrada-metrica">{self.estado_operacional['entrada']}</div>
    </div>
  </div>

  <div class="panel">
    <div class="panel-header">
      <span class="pair-badge" id="pair-badge">{self.ativo_atual} · M1 Tempo Real</span>
      <span class="change-up" id="change-badge" style="color:var(--{mudanca_cor})">{mudanca}</span>
    </div>
    <div class="chart-wrap" id="chart">
      <svg viewBox="0 0 900 220" width="100%" height="100%">
        <g stroke="#2a2440" stroke-width="1">
          <line x1="0" y1="30" x2="900" y2="30"/>
          <line x1="0" y1="80" x2="900" y2="80"/>
          <line x1="0" y1="130" x2="900" y2="130"/>
          <line x1="0" y1="180" x2="900" y2="180"/>
        </g>
        <g id="candles"></g>
        <path id="trendline" fill="none" stroke="#AFA9EC" stroke-width="1.5" opacity="0.45"/>
      </svg>
    </div>
    <div class="grid-3">
      <div class="metric">
        <div class="metric-label">RSI (14)</div>
        <div class="metric-value purple" id="rsi-metrica">—</div>
      </div>
      <div class="metric">
        <div class="metric-label">MACD</div>
        <div class="metric-value purple" id="macd-metrica">—</div>
      </div>
      <div class="metric">
        <div class="metric-label">ADX (14)</div>
        <div class="metric-value purple" id="adx-metrica">—</div>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn-primary" onclick="conectar_conta()">Preparar painel de sinais</button>
      <button class="btn-ghost" onclick="atualizar_dados()">🔄 Atualizar dados</button>
    </div>
  </div>

  <div class="panel">
    <div class="asset-toolbar">
      <div class="asset-modes" role="tablist">
        <button class="asset-mode active" id="aba-aberto" onclick="mostrar_mercado('aberto')">Mercado Aberto</button>
        <button class="asset-mode" id="aba-otc" onclick="mostrar_mercado('otc')">OTC</button>
      </div>
    </div>
    <div class="asset-view active" id="mercado-aberto">
      <div class="asset-grid">{principais_html}</div>
      <button class="asset-link" id="botao-mais-pares" onclick="alternar_pares_reais()">Mais pares reais ({len(ATIVOS_MERCADO_ABERTO) - 6})</button>
      <div class="asset-grid asset-extra" id="pares-reais-adicionais">{adicionais_html}</div>
      <details class="asset-optional">
        <summary>Adicionar par Forex manualmente</summary>
        <button onclick="adicionar_ativo()">Adicionar ativo</button>
      </details>
    </div>
    <div class="asset-view" id="mercado-otc">
      <p class="asset-note" id="nota-otc">Ativos OTC para leitura visual na plataforma selecionada.</p>
      <div class="asset-grid">{otc_html}</div>
    </div>
    <div class="form-grid">
      <div class="form-row">
        <label>Plataforma operacional</label>
        <select id="plataforma-input" onchange="mudar_plataforma()">
          <option value="IQ Option">IQ Option</option>
          <option value="Quotex">Quotex</option>
          <option value="Casa Trader">Casa Trader</option>
          <option value="Avallon">Avallon</option>
        </select>
      </div>
      <div class="form-row">
        <label>Banca simulada</label>
        <input type="number" min="0.01" step="0.01" value="{self.estado_operacional['banca']}" id="banca-input" onchange="atualizar_configuracao()">
      </div>
      <div class="form-row">
        <label>Valor entrada (USD)</label>
        <input type="number" min="0.01" step="0.01" value="{self.configuracao['entrada']}" id="entrada-input" onchange="atualizar_configuracao()">
      </div>
      <div class="form-row">
        <label>Stop gain</label>
        <input type="number" min="0.01" step="0.01" value="{self.configuracao['stop_gain']}" id="gain-input" onchange="atualizar_configuracao()">
      </div>
      <div class="form-row">
        <label>Stop loss</label>
        <input type="number" min="0.01" step="0.01" value="{self.configuracao['stop_loss']}" id="loss-input" onchange="atualizar_configuracao()">
      </div>
      <div class="form-row">
        <label>Liberação do monitoramento</label>
        <div class="form-state{' confirmada' if self.plataforma_confirmada == self.plataforma_atual else ''}" id="status-plataforma">
          {'Plataforma confirmada' if self.plataforma_confirmada == self.plataforma_atual else 'Confirme a plataforma'}
        </div>
      </div>
    </div>
    <div class="btn-row wide">
      <button class="btn-ghost" onclick="confirmar_plataforma()">Confirmar plataforma</button>
      <button class="btn-primary" onclick="iniciar_motor()">▶ Iniciar robô</button>
      <button class="btn-ghost" onclick="pausar_motor()">⏸ Pausar robô</button>
    </div>
  </div>

  <div class="panel">
    <div class="panel-header">
      <span class="panel-title">📋 Log do BFT (Tempo Real)</span>
    </div>
    <div class="log" id="log-container">
      {log_html}
    </div>
  </div>

  <button class="btn-danger-full" onclick="parada_emergencia()">⛔ Parada de emergência — clique aqui</button>

  <footer>BFT Winbot · Integração de Mercados Reais · Tempo Real Global</footer>
</div>

<script>
  function tratarResposta(resposta) {{
    if (!resposta.ok) {{
      return resposta.json().catch(() => ({{}})).then(dados => {{
        throw new Error(dados.erro || 'Falha ao executar ação');
      }});
    }}
    return resposta.json().catch(() => ({{}}));
  }}

  function formatarPreco(valor) {{
    return Number(valor).toLocaleString('pt-BR', {{
      minimumFractionDigits: 2,
      maximumFractionDigits: 6
    }});
  }}

  function renderizarLog(logs) {{
    const container = document.getElementById('log-container');
    container.replaceChildren(...logs.slice(-10).map(log => {{
      const linha = document.createElement('div');
      const etiqueta = document.createElement('span');
      etiqueta.className = 'log-tag';
      etiqueta.textContent = `[${{log.tipo}}] `;
      const mensagem = document.createElement('span');
      mensagem.className = log.nivel || 'info';
      mensagem.textContent = log.mensagem;
      linha.append(etiqueta, mensagem);
      return linha;
    }}));
    container.scrollTop = container.scrollHeight;
  }}

  function renderizarVelas(velas) {{
    const grupo = document.getElementById('candles');
    const tendencia = document.getElementById('trendline');
    grupo.replaceChildren();
    tendencia.setAttribute('d', '');
    if (!velas || velas.length === 0) return;

    const maxima = Math.max(...velas.map(vela => Number(vela.maxima)));
    const minima = Math.min(...velas.map(vela => Number(vela.minima)));
    const amplitude = maxima - minima || 1;
    const largura = 900 / velas.length;
    const larguraCorpo = Math.max(2, largura * 0.58);
    const y = valor => 190 - ((Number(valor) - minima) / amplitude) * 160;
    const pontosTendencia = [];

    velas.forEach((vela, indice) => {{
      const centroX = indice * largura + largura / 2;
      const subida = Number(vela.fechamento) >= Number(vela.abertura);
      const cor = subida ? '#97C459' : '#F09595';
      const pavio = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      pavio.setAttribute('x1', centroX);
      pavio.setAttribute('x2', centroX);
      pavio.setAttribute('y1', y(vela.maxima));
      pavio.setAttribute('y2', y(vela.minima));
      pavio.setAttribute('stroke', cor);
      pavio.setAttribute('stroke-width', '1');

      const corpo = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      corpo.setAttribute('x', centroX - larguraCorpo / 2);
      corpo.setAttribute('y', Math.min(y(vela.abertura), y(vela.fechamento)));
      corpo.setAttribute('width', larguraCorpo);
      corpo.setAttribute('height', Math.max(1, Math.abs(y(vela.abertura) - y(vela.fechamento))));
      corpo.setAttribute('fill', cor);

      grupo.append(pavio, corpo);
      pontosTendencia.push(`${{indice === 0 ? 'M' : 'L'}}${{centroX.toFixed(1)}},${{y(vela.fechamento).toFixed(1)}}`);
    }});
    tendencia.setAttribute('d', pontosTendencia.join(' '));
  }}

  function formatarIndicador(valor, casas = 2) {{
    return Number.isFinite(Number(valor)) ? Number(valor).toFixed(casas) : '—';
  }}

  function atualizarPainel() {{
    fetch('/api/status')
      .then(tratarResposta)
      .then(dados => {{
        const estado = dados.estado;
        document.getElementById('status-painel').textContent = estado.status;
        document.getElementById('banca-metrica').textContent = `$${{formatarPreco(estado.banca)}}`;
        document.getElementById('payout-metrica').textContent = `${{Number(estado.payout).toFixed(0)}}%`;
        document.getElementById('confluencia-metrica').textContent = estado.confluencia;
        document.getElementById('entrada-metrica').textContent = estado.entrada;
        const plataforma = dados.plataforma;
        const estadoPlataforma = document.getElementById('status-plataforma');
        document.getElementById('plataforma-input').value = plataforma.atual;
        estadoPlataforma.textContent = plataforma.confirmada ? 'Plataforma confirmada' : 'Confirme a plataforma';
        estadoPlataforma.classList.toggle('confirmada', plataforma.confirmada);

        if (dados.analise) {{
          document.getElementById('pair-badge').textContent = `${{dados.analise.ativo}} · ${{dados.analise.timeframe || 'M1'}} Tempo Real`;
          renderizarVelas(dados.analise.velas_grafico);
          const series = dados.analise.series_tecnicas || [];
          const indicadores = series[series.length - 1] || {{}};
          document.getElementById('rsi-metrica').textContent = formatarIndicador(indicadores.rsi);
          document.getElementById('macd-metrica').textContent = formatarIndicador(indicadores.macd, 5);
          document.getElementById('adx-metrica').textContent = formatarIndicador(indicadores.adx);
        }}

        const cotacao = dados.cotacoes[dados.ativo_atual];
        const badge = document.getElementById('change-badge');
        if (cotacao) {{
          const variacao = Number(cotacao.variacao_percentual);
          badge.textContent = `${{variacao >= 0 ? '+' : ''}}${{variacao.toFixed(2)}}% · $${{formatarPreco(cotacao.preco)}}`;
          badge.className = variacao >= 0 ? 'change-up' : 'change-down';
        }} else {{
          badge.textContent = 'Dados indisponíveis';
          badge.className = 'change-down';
        }}
        renderizarLog(dados.logs || []);
      }})
      .catch(erro => console.warn('Não foi possível atualizar o painel:', erro.message));
  }}

  function mudar_ativo(ativo) {{
    fetch(`/api/ativo/${{ativo}}`).then(tratarResposta).then(() => location.reload()).catch(erro => alert(erro.message));
  }}

  function conectar_conta() {{
    fetch('/api/conectar-conta', {{method:'POST'}}).then(tratarResposta).then(() => location.reload()).catch(erro => alert(erro.message));
  }}

  function mudar_plataforma() {{
    const plataforma = document.getElementById('plataforma-input').value;
    fetch('/api/plataforma', {{
      method:'POST',
      headers:{{'Content-Type':'application/json'}},
      body:JSON.stringify({{plataforma}})
    }}).then(tratarResposta).then(atualizarPainel).catch(erro => alert(erro.message));
  }}

  function confirmar_plataforma() {{
    fetch('/api/confirmar-plataforma', {{method:'POST'}})
      .then(tratarResposta)
      .then(atualizarPainel)
      .catch(erro => alert(erro.message));
  }}

  function atualizar_dados() {{
    fetch('/api/atualizar', {{method:'POST'}}).then(tratarResposta).then(atualizarPainel).catch(erro => alert(erro.message));
  }}

  function atualizar_configuracao() {{
    const configuracao = {{
      banca: parseFloat(document.getElementById('banca-input').value),
      entrada: parseFloat(document.getElementById('entrada-input').value),
      stop_gain: parseFloat(document.getElementById('gain-input').value),
      stop_loss: parseFloat(document.getElementById('loss-input').value)
    }};
    return fetch('/api/configuracao', {{
      method:'POST',
      headers:{{'Content-Type':'application/json'}},
      body:JSON.stringify(configuracao)
    }}).then(tratarResposta);
  }}

  function adicionar_ativo() {{
    const novo = prompt('Código do ativo (ex: BTC, EURUSD, PETR4):');
    if (novo) fetch(`/api/adicionar-ativo/${{novo}}`).then(tratarResposta).then(() => location.reload()).catch(erro => alert(erro.message));
  }}

  function iniciar_motor() {{
    atualizar_configuracao()
      .then(() => fetch('/api/iniciar', {{method:'POST'}}))
      .then(tratarResposta)
      .then(() => location.reload())
      .catch(erro => alert(erro.message));
  }}

  function pausar_motor() {{
    fetch('/api/pausar', {{method:'POST'}}).then(tratarResposta).then(() => location.reload()).catch(erro => alert(erro.message));
  }}

  function parada_emergencia() {{
    if (confirm('⚠️ Parar TODAS as operações agora?')) {{
      fetch('/api/parada-emergencia', {{method:'POST'}}).then(tratarResposta).then(() => location.reload()).catch(erro => alert(erro.message));
    }}
  }}

  window.setInterval(atualizarPainel, 15000);
</script>
</body>
</html>"""

    def gerar_json_api(self) -> Dict:
        """Gera dados em JSON para API REST."""
        cotacoes = {}
        for ativo in self.ativos_selecionados:
            cotacao = self.conector.obter_cotacao(ativo)
            if cotacao:
                cotacoes[ativo] = {
                    "preco": cotacao.preco,
                    "variacao": cotacao.variacao,
                    "variacao_percentual": cotacao.variacao_percentual,
                    "fonte": cotacao.fonte,
                    "horario": cotacao.horario.isoformat(),
                }

        with self.lock_analise:
          analise = None if self.ultima_analise is None else dict(self.ultima_analise)

        return {
            "timestamp": datetime.now().isoformat(),
            "estado": self.estado_operacional,
            "cotacoes": cotacoes,
            "ativo_atual": self.ativo_atual,
            "plataforma": {
              "atual": self.plataforma_atual,
              "confirmada": self.plataforma_confirmada == self.plataforma_atual,
            },
          "analise": analise,
            "logs": self.logs[-20:],
        }


class BFTRequestHandler(BaseHTTPRequestHandler):
    """Handler HTTP que serve a interface e os endpoints REST."""

    interface: "InterfaceTempoReal" = None

    def _enviar_json(self, dados, status=200):
        corpo = json.dumps(dados, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(corpo)))
        self.end_headers()
        self.wfile.write(corpo)

    def _enviar_html(self, html):
        corpo = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(corpo)))
        self.end_headers()
        self.wfile.write(corpo)

    def _enviar_erro(self, mensagem, status=400):
        self._enviar_json({"erro": mensagem}, status)

    def do_GET(self):
        """Trata requisições GET."""
        ifac = self.interface
        caminho = urlparse(self.path).path

        if caminho == "/" or caminho == "":
            self._enviar_html(ifac.gerar_html())
            return

        if caminho == "/api/status":
            self._enviar_json(ifac.gerar_json_api())
            return

        if caminho == "/assets/logo-bft.jpg":
          caminho_logo = os.path.join(PASTA_PROJETO, "assets", "logo-bft.jpg")
          try:
            with open(caminho_logo, "rb") as arquivo:
              imagem = arquivo.read()
          except OSError:
            self._enviar_erro("Logo não encontrada", 404)
            return
          self.send_response(200)
          self.send_header("Content-Type", "image/jpeg")
          self.send_header("Content-Length", str(len(imagem)))
          self.end_headers()
          self.wfile.write(imagem)
          return

        if caminho.startswith("/api/ativo/"):
            ativo = caminho.rsplit("/", 1)[-1].upper()
            if ifac.mudar_ativo(ativo):
                self._enviar_json({"ok": True, "ativo": ativo})
            else:
                self._enviar_erro(f"Ativo inválido: {ativo}", 404)
            return

        if caminho.startswith("/api/adicionar-ativo/"):
            ativo = caminho.rsplit("/", 1)[-1].upper()
            if ifac.adicionar_ativo(ativo):
                self._enviar_json({"ok": True, "ativo": ativo})
            else:
                self._enviar_erro(f"Ativo não suportado: {ativo}", 404)
            return

        self._enviar_erro("Endpoint não encontrado", 404)

    def do_POST(self):
        """Trata requisições POST."""
        ifac = self.interface
        caminho = urlparse(self.path).path

        if caminho == "/api/atualizar":
            ifac.registrar_log("MERCADO", "Atualização manual solicitada", "info")
            self._enviar_json({"ok": True, "mensagem": "Dados atualizados"})
            return

        if caminho == "/api/conectar-conta":
            ifac.conectar_conta()
            self._enviar_json({"ok": True, "mensagem": "Painel preparado"})
            return

        if caminho == "/api/plataforma":
          try:
            tamanho = int(self.headers.get("Content-Length", 0))
            corpo = self.rfile.read(tamanho) if tamanho else b"{}"
            dados = json.loads(corpo or b"{}")
            ifac.mudar_plataforma(str(dados.get("plataforma", "")).strip())
            self._enviar_json({"ok": True, "plataforma": ifac.plataforma_atual})
          except (ValueError, TypeError, json.JSONDecodeError) as erro:
            self._enviar_erro(f"Plataforma inválida: {erro}")
          return

        if caminho == "/api/confirmar-plataforma":
          ifac.confirmar_plataforma()
          self._enviar_json({"ok": True, "plataforma": ifac.plataforma_confirmada})
          return

        if caminho == "/api/banca":
            try:
                tamanho = int(self.headers.get("Content-Length", 0))
                corpo = self.rfile.read(tamanho) if tamanho else b"{}"
                dados = json.loads(corpo or b"{}")
                banca = float(dados.get("banca", 0))
                if banca <= 0:
                    raise ValueError("banca deve ser maior que zero")
                ifac.atualizar_banca(banca)
                self._enviar_json({"ok": True, "banca": banca})
            except (ValueError, json.JSONDecodeError) as erro:
                self._enviar_erro(f"Banca inválida: {erro}")
            return

        if caminho == "/api/configuracao":
            try:
                tamanho = int(self.headers.get("Content-Length", 0))
                corpo = self.rfile.read(tamanho) if tamanho else b"{}"
                dados = json.loads(corpo or b"{}")
                ifac.atualizar_configuracao(dados)
                self._enviar_json({"ok": True, "configuracao": ifac.configuracao})
            except (ValueError, TypeError, json.JSONDecodeError) as erro:
                self._enviar_erro(f"Configuração inválida: {erro}")
            return

        if caminho == "/api/iniciar":
            iniciado, mensagem = ifac.iniciar_motor()
            if iniciado:
                self._enviar_json({"ok": True, "mensagem": mensagem})
            else:
                self._enviar_erro(mensagem, 409)
            return

        if caminho == "/api/pausar":
            pausado, mensagem = ifac.pausar_motor()
            if pausado:
                self._enviar_json({"ok": True, "mensagem": mensagem})
            else:
                self._enviar_erro(mensagem, 409)
            return

        if caminho == "/api/parada-emergencia":
            _, mensagem = ifac.parada_emergencia()
            self._enviar_json({"ok": True, "mensagem": mensagem})
            return

        self._enviar_erro("Endpoint não encontrado", 404)

    def log_message(self, formato, *args):
        """Silencia logs do servidor para manter a saída limpa."""
        return


def criar_interface_tempo_real() -> InterfaceTempoReal:
    """Factory para criar interface com dados reais."""
    return InterfaceTempoReal()


def iniciar_servidor(host="127.0.0.1", porta=8765, interface=None):
    """Inicia o servidor HTTP das interface de tempo real."""
    if interface is None:
        interface = criar_interface_tempo_real()

    BFTRequestHandler.interface = interface
    servidor = ThreadingHTTPServer((host, porta), BFTRequestHandler)
    interface.registrar_log("INIT", f"Servidor BFT iniciado em http://{host}:{porta}", "ok")
    print(f"✅ BFT Tempo Real servindo em http://{host}:{porta}")
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Servidor encerrado.")
    finally:
        servidor.server_close()


if __name__ == "__main__":
    interface = criar_interface_tempo_real()
    interface.registrar_log("INIT", "Interface BFT iniciada", "ok")
    interface.registrar_log("MERCADO", "Conectando a dados reais...", "info")

    # Atualizar algumas cotações iniciais
    for ativo in ["BTC", "ETH", "EURUSD"]:
        cotacao = interface.conector.obter_cotacao(ativo)
        if cotacao:
            interface.registrar_log(
                "MERCADO",
                f"{ativo}: {cotacao.preco:.2f} ({cotacao.variacao_percentual:+.2f}%)",
                "ok",
            )
        else:
            interface.registrar_log("MERCADO", f"Não foi possível obter {ativo}", "warn")

    iniciar_servidor(interface=interface)
