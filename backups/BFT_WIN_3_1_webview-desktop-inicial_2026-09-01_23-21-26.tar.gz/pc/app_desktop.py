"""Abre o Trading Desk Web como aplicativo nativo do macOS."""

import subprocess
import sys
import time
from pathlib import Path
from urllib.request import urlopen

import webview


RAIZ_PROJETO = Path(__file__).resolve().parent.parent
URL_DASHBOARD = "http://127.0.0.1:8765"


def servidor_disponivel():
    try:
        with urlopen(f"{URL_DASHBOARD}/api/status", timeout=1):
            return True
    except OSError:
        return False


def iniciar_servidor():
    if servidor_disponivel():
        return None

    processo = subprocess.Popen(
        [sys.executable, str(RAIZ_PROJETO / "web" / "interface_tempo_real.py")],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for _ in range(30):
        if servidor_disponivel():
            return processo
        time.sleep(0.2)
    processo.terminate()
    raise RuntimeError("Não foi possível iniciar o Trading Desk local.")


def main():
    processo_servidor = iniciar_servidor()
    try:
        webview.create_window(
            "BFT Winbot - Trading Desk",
            URL_DASHBOARD,
            width=1200,
            height=900,
            min_size=(900, 650),
        )
        webview.start(gui="cocoa", debug=True)
    finally:
        if processo_servidor is not None:
            processo_servidor.terminate()


if __name__ == "__main__":
    main()