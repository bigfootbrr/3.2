"""Identidade e versão única do aplicativo BFT WIN."""

NOME_APP = "BFT WIN"
VERSAO_APP = "3.1"
NOME_COMPLETO_APP = f"{NOME_APP} {VERSAO_APP}"
