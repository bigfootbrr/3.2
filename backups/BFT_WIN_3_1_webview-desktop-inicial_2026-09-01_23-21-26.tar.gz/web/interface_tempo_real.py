"""Interface web final com dados reais de mercado em tempo real.

Serve uma interface HTML em um servidor HTTP local e expõe endpoints REST
que se conectam ao motor do BFT WIN para iniciar, pausar, parar e configurar
operações, além de fornecer cotações reais.
"""

import json
import os
import sys
import threading
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Dict, List, Optional
from urllib.parse import urlparse, parse_qs

PASTA_PROJETO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(PASTA_PROJETO, "core"))

from conector_mercado_real import ConectorMercadoReal, criar_conector_padrao


class InterfaceTempoReal:
    """Interface web integrada com dados reais de mercado."""

    def __init__(self):
        self.conector = criar_conector_padrao()
        self.ativos_selecionados = ["BTC", "ETH", "EURUSD", "IBOV"]
        self.ativo_atual = "BTC"
        self.logs = []
        self.estado_operacional = {
            "status": "Parado",
            "banca": 1000.00,
            "payout": 0.0,
            "confluencia": "—",
            "entrada": "Bloqueada",
        }
        self.historico_velas = {}
        self.threads_atualizacao = {}
        self.motor_ativo = False
        self.motor_pausado = False

    def registrar_log(self, tipo: str, mensagem: str, nivel: str = "info"):
        """Registra mensagem no log."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        entrada = {
            "timestamp": timestamp,
            "tipo": tipo,
            "mensagem": mensagem,
            "nivel": nivel,  # "info", "ok", "warn", "error"
        }
        self.logs.append(entrada)
        # Manter apenas últimos 50 logs
        if len(self.logs) > 50:
            self.logs = self.logs[-50:]
        print(f"[{timestamp}] [{tipo}] {mensagem}")

    def mudar_ativo(self, ativo: str):
        """Muda o ativo selecionado."""
        if ativo in self.ativos_selecionados or ativo in self.conector.ATIVOS_DISPONIVEIS:
            self.ativo_atual = ativo
            if ativo not in self.ativos_selecionados:
                self.ativos_selecionados.append(ativo)
            self.registrar_log("ATIVO", f"Ativo alterado para {ativo}", "ok")
            return True
        self.registrar_log("ATIVO", f"Ativo inválido: {ativo}", "warn")
        return False

    def adicionar_ativo(self, ativo: str):
        """Adiciona novo ativo à lista de acompanhamento."""
        ativo = ativo.strip().upper()
        if ativo in self.conector.ATIVOS_DISPONIVEIS:
            if ativo not in self.ativos_selecionados:
                self.ativos_selecionados.append(ativo)
            self.registrar_log("ATIVO", f"Ativo {ativo} adicionado", "ok")
            return True
        self.registrar_log("ATIVO", f"Ativo não suportado: {ativo}", "warn")
        return False

    def atualizar_banca(self, banca: float):
        """Atualiza banca operacional."""
        self.estado_operacional["banca"] = float(banca)
        self.registrar_log("BANCA", f"Banca atualizada para {banca:.2f}", "ok")

    def conectar_conta(self):
        """Simula conexão com conta real."""
        self.estado_operacional["status"] = "Conectado — modo real"
        self.estado_operacional["entrada"] = "Liberada"
        self.registrar_log("CONTA", "Conta real conectada", "ok")

    def iniciar_motor(self):
        """Inicia o motor do BFT WIN."""
        self.motor_ativo = True
        self.motor_pausado = False
        self.estado_operacional["status"] = "Rodando — modo real"
        self.estado_operacional["entrada"] = "Em análise"
        self.registrar_log("MOTOR", "Motor do BFT WIN iniciado", "ok")

    def pausar_motor(self):
        """Pausa o motor do BFT WIN."""
        self.motor_pausado = True
        self.estado_operacional["status"] = "Pausado — modo real"
        self.registrar_log("MOTOR", "Motor do BFT WIN pausado", "warn")

    def parada_emergencia(self):
        """Executa parada de emergência."""
        self.motor_ativo = False
        self.motor_pausado = False
        self.estado_operacional["status"] = "EMERGÊNCIA — tudo parado"
        self.estado_operacional["entrada"] = "Bloqueada"
        self.registrar_log("EMERGENCIA", "PARADA DE EMERGÊNCIA ACIONADA", "error")

    def gerar_html(self) -> str:
        """Gera HTML da interface com dados reais."""
        cotacoes = {}
        for ativo in self.ativos_selecionados:
            cotacao = self.conector.obter_cotacao(ativo)
            if cotacao:
                cotacoes[ativo] = cotacao

        ativo_selecionado = cotacoes.get(self.ativo_atual)

        # Métrica de mudança de preço
        mudanca = ""
        mudanca_cor = "green"
        if ativo_selecionado:
            if ativo_selecionado.variacao_percentual > 0:
                mudanca = f"+{ativo_selecionado.variacao_percentual:.2f}%"
            else:
                mudanca = f"{ativo_selecionado.variacao_percentual:.2f}%"
                mudanca_cor = "red"

        # Log formatado
        log_html = "\n".join(
            [
                f'<div><span class="log-tag">[{log["tipo"]}]</span> '
                f'<span class="{log["nivel"]}">{log["mensagem"]}</span></div>'
                for log in self.logs[-10:]
            ]
        )

        # Abas de ativos
        abas_html = "\n".join(
            [
                f'<div class="tab active" onclick="mudar_ativo(\'{ativo}\')" style="cursor:pointer;">{ativo}</div>'
                if ativo == self.ativo_atual
                else f'<div class="tab" onclick="mudar_ativo(\'{ativo}\')" style="cursor:pointer;">{ativo}</div>'
                for ativo in self.ativos_selecionados
            ]
        )

        return f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>BFT Winbot — Trading Desk (Tempo Real)</title>
<style>
  :root{{
    --bg-0:#0a0812;
    --bg-1:#100c1c;
    --bg-2:#171229;
    --bg-3:#1e1834;
    --line:#2a2440;
    --line-strong:#3C3489;
    --purple-50:#EEEDFE;
    --purple-100:#CECBF6;
    --purple-200:#AFA9EC;
    --purple-400:#7F77DD;
    --purple-600:#534AB7;
    --purple-800:#3C3489;
    --text-1:#F1EFFB;
    --text-2:#9A93C9;
    --text-3:#6B6494;
    --green:#639922;
    --green-light:#97C459;
    --red:#E24B4A;
    --red-light:#F09595;
    --amber:#EF9F27;
    font-family:'Inter','Segoe UI',system-ui,-apple-system,sans-serif;
  }}
  *{{box-sizing:border-box;margin:0;padding:0;}}
  body{{
    background:radial-gradient(circle at 20% 0%, #14102450, transparent 55%), var(--bg-0);
    color:var(--text-1);
    min-height:100vh;
    padding:32px 16px 80px;
  }}
  .shell{{max-width:980px;margin:0 auto;}}

  .topbar{{
    display:flex;align-items:center;justify-content:space-between;
    padding:14px 20px;background:var(--bg-1);border:0.5px solid var(--line);
    border-radius:14px;margin-bottom:16px;
  }}
  .brand{{display:flex;align-items:center;gap:12px;}}
  .brand-mark{{
    width:40px;height:40px;border-radius:11px;
    background:linear-gradient(160deg,var(--purple-400),var(--purple-800));
    display:flex;align-items:center;justify-content:center;
    box-shadow:0 0 0 1px var(--line-strong);
  }}
  .brand-mark svg{{width:22px;height:22px;}}
  .brand h1{{font-size:16px;font-weight:600;letter-spacing:-0.01em;}}
  .brand p{{font-size:11.5px;color:var(--text-2);margin-top:1px;}}
  .status-pill{{
    display:flex;align-items:center;gap:7px;
    background:var(--bg-2);border:0.5px solid var(--line-strong);
    border-radius:99px;padding:7px 14px;font-size:12px;color:var(--purple-100);
  }}
  .dot{{width:7px;height:7px;border-radius:50%;background:var(--amber);
       box-shadow:0 0 6px var(--amber);}}

  .grid-4{{
    display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px;
  }}
  .metric{{
    background:var(--bg-1);border:0.5px solid var(--line);border-radius:12px;
    padding:14px 16px;
  }}
  .metric.danger{{border-color:#5a2323;background:#1e1112;}}
  .metric-label{{font-size:11px;color:var(--text-2);margin-bottom:6px;text-transform:none;}}
  .metric-value{{font-size:19px;font-weight:600;}}
  .metric-value.green{{color:var(--green-light);}}
  .metric-value.purple{{color:var(--purple-200);}}
  .metric-value.red{{color:var(--red-light);}}

  .panel{{
    background:var(--bg-1);border:0.5px solid var(--line);border-radius:14px;
    padding:18px;margin-bottom:16px;
  }}
  .panel-header{{
    display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;
  }}
  .panel-title{{font-size:13px;color:var(--text-2);}}
  .pair-badge{{
    font-size:12px;color:var(--text-2);background:var(--bg-2);
    border:0.5px solid var(--line);border-radius:8px;padding:4px 10px;
  }}
  .change-up{{color:var(--green-light);font-size:12.5px;font-weight:500;}}
  .change-down{{color:var(--red-light);font-size:12.5px;font-weight:500;}}

  .chart-wrap{{width:100%;height:220px;}}

  .btn-row{{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px;}}
  .btn-row.wide{{grid-template-columns:1fr;}}
  button{{
    font-family:inherit;font-size:13px;font-weight:500;
    border-radius:10px;padding:12px 14px;cursor:pointer;
    transition:filter .15s ease, transform .1s ease;border:none;
  }}
  button:active{{transform:scale(0.98);}}
  .btn-primary{{
    background:linear-gradient(180deg,var(--purple-600),var(--purple-800));
    border:0.5px solid var(--purple-400);color:var(--purple-50);
  }}
  .btn-primary:hover{{filter:brightness(1.12);}}
  .btn-ghost{{
    background:transparent;border:0.5px solid var(--line-strong);color:var(--purple-200);
  }}
  .btn-ghost:hover{{background:var(--bg-2);}}
  .btn-danger-full{{
    width:100%;margin-top:20px;background:linear-gradient(180deg,#9c2b2b,#6b1c1c);
    border:0.5px solid #c33; color:#ffe3e3; font-size:14px; font-weight:600;
    padding:15px; letter-spacing:0.02em; display:flex; align-items:center; justify-content:center; gap:8px;
  }}
  .btn-danger-full:hover{{filter:brightness(1.1);}}

  .tabs{{display:flex;gap:4px;margin-bottom:14px;overflow-x:auto;}}
  .tab{{
    font-size:12.5px;color:var(--text-2);background:transparent;
    border:0.5px solid var(--line);padding:8px 14px;border-radius:9px;
    white-space:nowrap;cursor:pointer;
  }}
  .tab.active{{background:var(--bg-2);color:var(--text-1);border-color:var(--line-strong);}}

  .form-row{{margin-bottom:12px;}}
  .form-row label{{display:block;font-size:11.5px;color:var(--text-2);margin-bottom:6px;}}
  .form-row input{{
    width:100%;background:var(--bg-2);border:0.5px solid var(--line);
    border-radius:9px;padding:10px 12px;color:var(--text-1);font-size:13.5px;
  }}
  .form-row input:focus{{outline:none;border-color:var(--purple-400);}}
  .form-grid{{display:grid;grid-template-columns:1fr 1fr;gap:12px;}}

  .log{{
    background:#0c0a15;border:0.5px solid var(--line);border-radius:10px;
    padding:12px 14px;font-family:'SFMono-Regular',Consolas,'Courier New',monospace;
    font-size:11.5px;line-height:1.7;color:var(--text-2);max-height:160px;overflow-y:auto;
  }}
  .log .ok{{color:var(--green-light);}}
  .log .warn{{color:var(--amber);}}
  .log .error{{color:var(--red-light);}}
  .log-tag{{color:var(--purple-200);}}

  footer{{text-align:center;font-size:11px;color:var(--text-3);margin-top:20px;}}

  .pulse {{animation: pulse 1.5s ease-in-out infinite;}}
  @keyframes pulse {{
    0%, 100% {{ opacity: 1; }}
    50% {{ opacity: 0.7; }}
  }}
</style>
</head>
<body>
<div class="shell">

  <div class="topbar">
    <div class="brand">
      <div class="brand-mark">
        <svg viewBox="0 0 24 24" fill="none" stroke="#EEEDFE" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M3 17l6-6 4 4 8-8"/><path d="M17 5h4v4"/>
        </svg>
      </div>
      <div>
        <h1>BFT Winbot</h1>
        <p>Tempo Real — Mercados Globais</p>
      </div>
    </div>
    <div class="status-pill">
      <span class="dot pulse"></span>
      {self.estado_operacional['status']} — modo real
    </div>
  </div>

  <div class="grid-4">
    <div class="metric">
      <div class="metric-label">Banca operacional</div>
      <div class="metric-value purple">${self.estado_operacional['banca']:,.2f}</div>
    </div>
    <div class="metric">
      <div class="metric-label">Payout máximo</div>
      <div class="metric-value green">{self.estado_operacional['payout']:.0f}%</div>
    </div>
    <div class="metric">
      <div class="metric-label">Confluência</div>
      <div class="metric-value purple">{self.estado_operacional['confluencia']}</div>
    </div>
    <div class="metric danger">
      <div class="metric-label" style="color:#F09595">Status entrada</div>
      <div class="metric-value red">{self.estado_operacional['entrada']}</div>
    </div>
  </div>

  <div class="panel">
    <div class="panel-header">
      <span class="pair-badge" id="pair-badge">{self.ativo_atual} · M1 Tempo Real</span>
      <span class="change-up" id="change-badge" style="color:var(--{mudanca_cor})">{mudanca}</span>
    </div>
    <div class="chart-wrap" id="chart">
      <svg viewBox="0 0 900 220" width="100%" height="100%">
        <g stroke="#2a2440" stroke-width="1">
          <line x1="0" y1="30" x2="900" y2="30"/>
          <line x1="0" y1="80" x2="900" y2="80"/>
          <line x1="0" y1="130" x2="900" y2="130"/>
          <line x1="0" y1="180" x2="900" y2="180"/>
        </g>
        <g id="candles"></g>
        <path id="trendline" fill="none" stroke="#AFA9EC" stroke-width="1.5" opacity="0.45"/>
      </svg>
    </div>
    <div class="btn-row">
      <button class="btn-primary" onclick="conectar_conta()">Conectar / espelhar conta real</button>
      <button class="btn-ghost" onclick="atualizar_dados()">🔄 Atualizar dados</button>
    </div>
  </div>

  <div class="panel">
    <div class="tabs">
      {abas_html}
      <div class="tab" style="margin-left:auto;cursor:pointer;" onclick="adicionar_ativo()">+ Adicionar ativo</div>
    </div>
    <div class="form-grid">
      <div class="form-row">
        <label>Banca simulada</label>
        <input type="text" value="{self.estado_operacional['banca']}" id="banca-input" onchange="atualizar_banca(this.value)">
      </div>
      <div class="form-row">
        <label>Valor entrada (USD)</label>
        <input type="text" value="25" id="entrada-input">
      </div>
      <div class="form-row">
        <label>Stop gain</label>
        <input type="text" value="100" id="gain-input">
      </div>
      <div class="form-row">
        <label>Stop loss</label>
        <input type="text" value="100" id="loss-input">
      </div>
    </div>
    <div class="btn-row wide">
      <button class="btn-primary" onclick="iniciar_motor()">▶ Iniciar robô</button>
      <button class="btn-ghost" onclick="pausar_motor()">⏸ Pausar robô</button>
    </div>
  </div>

  <div class="panel">
    <div class="panel-header">
      <span class="panel-title">📋 Log do BFT (Tempo Real)</span>
    </div>
    <div class="log" id="log-container">
      {log_html}
    </div>
  </div>

  <button class="btn-danger-full" onclick="parada_emergencia()">⛔ Parada de emergência — clique aqui</button>

  <footer>BFT Winbot · Integração de Mercados Reais · Tempo Real Global</footer>
</div>

<script>
  function mudar_ativo(ativo) {{
    fetch(`/api/ativo/${{ativo}}`).then(() => location.reload());
  }}

  function conectar_conta() {{
    fetch('/api/conectar-conta', {{method:'POST'}}).then(() => location.reload());
  }}

  function atualizar_dados() {{
    fetch('/api/atualizar', {{method:'POST'}}).then(() => location.reload());
  }}

  function atualizar_banca(valor) {{
    fetch('/api/banca', {{method:'POST', headers:{{'Content-Type':'application/json'}}, body:JSON.stringify({{banca:parseFloat(valor)}})}});
  }}

  function adicionar_ativo() {{
    const novo = prompt('Código do ativo (ex: BTC, EURUSD, PETR4):');
    if (novo) fetch(`/api/adicionar-ativo/${{novo}}`).then(() => location.reload());
  }}

  function iniciar_motor() {{
    fetch('/api/iniciar', {{method:'POST'}}).then(() => location.reload());
  }}

  function pausar_motor() {{
    fetch('/api/pausar', {{method:'POST'}}).then(() => location.reload());
  }}

  function parada_emergencia() {{
    if (confirm('⚠️ Parar TODAS as operações agora?')) {{
      fetch('/api/parada-emergencia', {{method:'POST'}}).then(() => location.reload());
    }}
  }}
</script>
</body>
</html>"""

    def gerar_json_api(self) -> Dict:
        """Gera dados em JSON para API REST."""
        cotacoes = {}
        for ativo in self.ativos_selecionados:
            cotacao = self.conector.obter_cotacao(ativo)
            if cotacao:
                cotacoes[ativo] = {
                    "preco": cotacao.preco,
                    "variacao": cotacao.variacao,
                    "variacao_percentual": cotacao.variacao_percentual,
                    "fonte": cotacao.fonte,
                    "horario": cotacao.horario.isoformat(),
                }

        return {
            "timestamp": datetime.now().isoformat(),
            "estado": self.estado_operacional,
            "cotacoes": cotacoes,
            "ativo_atual": self.ativo_atual,
            "logs": self.logs[-20:],
        }


class BFTRequestHandler(BaseHTTPRequestHandler):
    """Handler HTTP que serve a interface e os endpoints REST."""

    interface: "InterfaceTempoReal" = None

    def _enviar_json(self, dados, status=200):
        corpo = json.dumps(dados, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(corpo)))
        self.end_headers()
        self.wfile.write(corpo)

    def _enviar_html(self, html):
        corpo = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(corpo)))
        self.end_headers()
        self.wfile.write(corpo)

    def _enviar_erro(self, mensagem, status=400):
        self._enviar_json({"erro": mensagem}, status)

    def do_GET(self):
        """Trata requisições GET."""
        ifac = self.interface
        caminho = urlparse(self.path).path

        if caminho == "/" or caminho == "":
            self._enviar_html(ifac.gerar_html())
            return

        if caminho == "/api/status":
            self._enviar_json(ifac.gerar_json_api())
            return

        if caminho.startswith("/api/ativo/"):
            ativo = caminho.rsplit("/", 1)[-1].upper()
            if ifac.mudar_ativo(ativo):
                self._enviar_json({"ok": True, "ativo": ativo})
            else:
                self._enviar_erro(f"Ativo inválido: {ativo}", 404)
            return

        if caminho.startswith("/api/adicionar-ativo/"):
            ativo = caminho.rsplit("/", 1)[-1].upper()
            if ifac.adicionar_ativo(ativo):
                self._enviar_json({"ok": True, "ativo": ativo})
            else:
                self._enviar_erro(f"Ativo não suportado: {ativo}", 404)
            return

        self._enviar_erro("Endpoint não encontrado", 404)

    def do_POST(self):
        """Trata requisições POST."""
        ifac = self.interface
        caminho = urlparse(self.path).path

        if caminho == "/api/atualizar":
            ifac.registrar_log("MERCADO", "Atualização manual solicitada", "info")
            self._enviar_json({"ok": True, "mensagem": "Dados atualizados"})
            return

        if caminho == "/api/conectar-conta":
            ifac.conectar_conta()
            self._enviar_json({"ok": True, "mensagem": "Conta conectada"})
            return

        if caminho == "/api/banca":
            try:
                tamanho = int(self.headers.get("Content-Length", 0))
                corpo = self.rfile.read(tamanho) if tamanho else b"{}"
                dados = json.loads(corpo or b"{}")
                banca = float(dados.get("banca", 0))
                if banca <= 0:
                    raise ValueError("banca deve ser maior que zero")
                ifac.atualizar_banca(banca)
                self._enviar_json({"ok": True, "banca": banca})
            except (ValueError, json.JSONDecodeError) as erro:
                self._enviar_erro(f"Banca inválida: {erro}")
            return

        if caminho == "/api/iniciar":
            ifac.iniciar_motor()
            self._enviar_json({"ok": True, "mensagem": "Motor iniciado"})
            return

        if caminho == "/api/pausar":
            ifac.pausar_motor()
            self._enviar_json({"ok": True, "mensagem": "Motor pausado"})
            return

        if caminho == "/api/parada-emergencia":
            ifac.parada_emergencia()
            self._enviar_json({"ok": True, "mensagem": "Emergência acionada"})
            return

        self._enviar_erro("Endpoint não encontrado", 404)

    def log_message(self, formato, *args):
        """Silencia logs do servidor para manter a saída limpa."""
        return


def criar_interface_tempo_real() -> InterfaceTempoReal:
    """Factory para criar interface com dados reais."""
    return InterfaceTempoReal()


def iniciar_servidor(host="127.0.0.1", porta=8765, interface=None):
    """Inicia o servidor HTTP das interface de tempo real."""
    if interface is None:
        interface = criar_interface_tempo_real()

    BFTRequestHandler.interface = interface
    servidor = ThreadingHTTPServer((host, porta), BFTRequestHandler)
    interface.registrar_log("INIT", f"Servidor BFT iniciado em http://{host}:{porta}", "ok")
    print(f"✅ BFT Tempo Real servindo em http://{host}:{porta}")
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Servidor encerrado.")
    finally:
        servidor.server_close()


if __name__ == "__main__":
    interface = criar_interface_tempo_real()
    interface.registrar_log("INIT", "Interface BFT iniciada", "ok")
    interface.registrar_log("MERCADO", "Conectando a dados reais...", "info")

    # Atualizar algumas cotações iniciais
    for ativo in ["BTC", "ETH", "EURUSD"]:
        cotacao = interface.conector.obter_cotacao(ativo)
        if cotacao:
            interface.registrar_log(
                "MERCADO",
                f"{ativo}: {cotacao.preco:.2f} ({cotacao.variacao_percentual:+.2f}%)",
                "ok",
            )
        else:
            interface.registrar_log("MERCADO", f"Não foi possível obter {ativo}", "warn")

    iniciar_servidor(interface=interface)
