"""Abre o Trading Desk Web como aplicativo nativo do macOS."""

import subprocess
import sys
import time
from pathlib import Path
from urllib.parse import urlparse
import socket

import webview


RAIZ_PROJETO = Path(__file__).resolve().parent.parent
URL_DASHBOARD = "http://127.0.0.1:8765"


def servidor_disponivel():
    endereco = urlparse(URL_DASHBOARD)
    try:
        with socket.create_connection(
            (endereco.hostname, endereco.port or 80), timeout=1
        ):
            return True
    except OSError:
        return False


def iniciar_servidor():
    if servidor_disponivel():
        return None

    processo = subprocess.Popen(
        [sys.executable, str(RAIZ_PROJETO / "web" / "interface_tempo_real.py")],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for _ in range(30):
        if servidor_disponivel():
            return processo
        time.sleep(0.2)
    encerrar_servidor(processo)
    raise RuntimeError("Não foi possível iniciar o Trading Desk local.")


def encerrar_servidor(processo):
    """Encerra o servidor filho sem deixar processo local em segundo plano."""
    processo.terminate()
    try:
        processo.wait(timeout=5)
    except subprocess.TimeoutExpired:
        processo.kill()
        processo.wait()


def main():
    processo_servidor = iniciar_servidor()
    try:
        webview.create_window(
            "BFT Winbot - Trading Desk",
            URL_DASHBOARD,
            width=1200,
            height=900,
            min_size=(900, 650),
        )
        webview.start(gui="cocoa", debug=True)
    finally:
        if processo_servidor is not None:
            encerrar_servidor(processo_servidor)


if __name__ == "__main__":
    main()